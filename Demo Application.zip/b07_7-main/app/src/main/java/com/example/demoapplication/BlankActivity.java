package com.example.demoapplication;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

import com.example.demoapplication.R;

public class BlankActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blank);

    }
}