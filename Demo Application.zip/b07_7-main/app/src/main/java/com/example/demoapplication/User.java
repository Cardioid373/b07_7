package com.example.demoapplication;

public class User {
    private String password;

    public User() {

    }

    public User(String password) {
        this.password = password;
    }

    public String getPassword() {
        return password;
    }
}