package com.example.demoapplication;

public class Admin {
    private String password;
    public Admin() {
    }
    public Admin(String password) {
        this.password = password;
    }

    public String getPassword() {
        return password;
    }
}